const Router = require('express').Router();
const Users = require('./model.js')



Router.post('/new',function(req,res){
	users=new Users({
		userId: Math.floor(Math.random() * 50)
		nombre:req.body.user,
		password:req.body.pass

	})
	users.save(function(err){
		if(err){
			res.status(500)
            res.json(error)
		}
		res.send("Usuario creado")
	})

})
Router.post('/log',function(req,res){
	Users.findOne({
					nombre:req.body.nombre,
					password:req.body.pass
				  }).exec(function(err, docs) {
				        if (err) {
				            res.status(500)
				            res.json(err)
				        }
				        res.json(docs)
				    })
})

//Obtener todos los usuarios
Router.get('/all', function(req, res) {
    Users.find({}).exec(function(err, docs) {
        if (err) {
            res.status(500)
            res.json(err)
        }
        res.json(docs)
    })
})

module.exports = Router